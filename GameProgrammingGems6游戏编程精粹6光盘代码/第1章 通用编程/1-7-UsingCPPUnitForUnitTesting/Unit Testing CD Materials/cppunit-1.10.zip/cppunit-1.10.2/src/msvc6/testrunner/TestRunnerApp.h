// TestRunner.h : main header file for the TESTRUNNER application
//

#if !defined(AFX_TESTRUNNER_H)
#define AFX_TESTRUNNER_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
    #error include 'stdafx.h' before including this file for PCH
#endif

// Handle to the instance to retreive module resource.
extern HINSTANCE g_testRunnerResource;


#endif // !defined(AFX_TESTRUNNER_H)
