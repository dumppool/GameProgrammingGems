Dependencies:
MSVCP70.dll, MSVcR70.dll
opengl32.dll, glu32.dll (these two should be there already)

Note:
This executable of PlayerViz was compiled using Microsoft Visual Studio 7, and therefore it requires some dll files. Due to licensing concerns, we can not distribute those dll files with PlayerViz.  

These two dll files (MSVCP70.dll and MSVcR70.dll) can be easily downloaded online by searching for them by name in a search engine.  Once you download the files please place them in the same folder as the executable.

We apologize for the inconvenience.