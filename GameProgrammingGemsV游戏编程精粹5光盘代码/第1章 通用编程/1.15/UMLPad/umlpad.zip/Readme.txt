UML Pad ver 1.15

Author: Luigi Bignami
		bignamil@tiscalinet.it
		http://web.tiscalinet.it/ggbhome

UML Pad is a CASE tool for UML diagrams design.
It supports Class, Sequence, State and Activity diagrams.
It allows printing and exporting of the diagram images.
For Class diagrams it's also possible to export the documentation in html format.
The program is available for free.

The project has been realized with support of the wxWindows class library
(see www.wxwindows.org).

Comments, bug notices and appreciations may be sent to:
bignamil@tiscalinet.it.
