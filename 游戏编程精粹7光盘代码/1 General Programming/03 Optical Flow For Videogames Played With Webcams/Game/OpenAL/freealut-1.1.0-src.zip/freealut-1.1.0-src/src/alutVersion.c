#include "alutInternal.h"

ALint
alutGetMajorVersion (void)
{
  return ALUT_API_MAJOR_VERSION;
}

ALint
alutGetMinorVersion (void)
{
  return ALUT_API_MINOR_VERSION;
}
